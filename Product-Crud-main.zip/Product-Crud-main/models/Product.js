const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Product name is required"],
        trim: true
    },
    price: {
        type: Number,
        required: true,
        min: [0, "Price must be positive"]
    },
    category: {
        type: String,
        required: true
    },
    inStock: {
        type: Boolean,
        default: true
    }
}, {
    timestamps: true
});

// Instance Method
productSchema.methods.applyDiscount = function (discount) {
    this.price = this.price - (this.price * discount / 100);
    return this.price;
};

// Middleware (pre-save)
productSchema.pre('save', function(next) {
    console.log("Product is about to be saved...");
    next();
});

module.exports = mongoose.model('Product', productSchema);